import java.io.*;//the ai chooses the first empty node it comes across
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Component;
import java.awt.Graphics;

class close extends WindowAdapter //Ends the game when closed
{
	public void windowClosing(WindowEvent e)
	{
		System.out.println("Goodbye");
		System.exit(0);
	}
}

public class gui7 extends JFrame implements ActionListener
{
	JButton color; //Change the color
	JLabel output;
	JTextArea input; //Selecting which piece to play
	
	monalisa playArea; //The entire play area
	
	class Circ //The Circle class
	{
		int x; //X coordinate 
		int y;//Y coordinate
		int length; //How lonk
		int height; //How toll
		Color color; //What colow
		int owned; //Who controls this circel
		
		public Circ() //Make a base circle
		{
			length=100;
			height=100;
			x=500; //Will be changeg
			y=500; //Will be changed
			color=new Color( 255,255,255);
			owned=0;
		}
		
		
		public void newcolor() //When someone wants to make a play
		{
			if (gameOver == false) //If the game is not over
			{
				if (owned == 0 && myTurn == false) //AI turn and unclaimed
				{
					color=new Color(255, 0, 0); //Make red
					owned++; //Used for win calculation
					myTurn = true; //Make it the player turn
					checkWin(); //Check for a win
				}
				if (owned == 0 && myTurn == true) //Player turn
				{
					color=new Color(0, 0, 255); //Make blue
					owned--;
					myTurn = false;	//Make it AI turn
					checkWin();
					if(!gameOver)
						ai();
					
				}
			}
		}
		
		public void reset()
		{
			color=new Color(255, 255, 255);
			owned =0;
		}
		
		
		public void draw(Graphics g) //From original code
		{
			g.setColor(color);
			g.fillOval(x,y, length,height);
			int [] xlist={x, x, x};
			int [] ylist={y, y, y};
			g.fillPolygon(xlist,ylist,3);
			
		}
	}
	
	class line //The lines
	{
		int x1; //Starting x
		int x2; //Ending x
		int y1; //Starting y
		int y2; //Ending y
		Color color;
			
			public line() //All but color will be changed
			{
				x1 = 10;
				x2 = 10;
				y1 = 10;
				y2 = 10;
				color=new Color( 255,255,255);
			}
			
			
	}
	
	Circ [] field; //Array of circles
	line [] connect; //Array of lines
	boolean myTurn; //Check if its my turn, need to add way to start with opponent
	int [][] win = new int[3][9]; //3 by 9 array for win conditions
	boolean gameOver = false; //Check if the gameis over
	int presses = 0;
	
	class monalisa extends JPanel
	{
		public monalisa() { setSize(700,500); }
		
		public void paintComponent(Graphics g) //Making the pretty picture
		{
			g.setColor(Color.black);
			g.fillRect(0,0, 900,600);
			position (100,50,0);
			position (350,50,1);
			position (600,50,2);
			position (200,200,3);
			position (350,200,4);
			position (500,200,5);
			position (100,350,6);
			position (350,350,7);
			position (600,350,8);
			g.setColor(Color.white);
			g.drawLine(150,100,650,100);
			g.drawLine(150,100,650,400);
			g.drawLine(125,100,375,375);
			g.drawLine(400,100,150,375);
			g.drawLine(400,100,650,400);
			g.drawLine(650,100,150,400);
			g.drawLine(650,100,400,400);
			g.drawLine(150,400,650,400);
			g.drawLine(250,250,500,250);
			for (int loc = 0; loc < 9; loc++)
				field[loc].draw(g);
			makeWin();
		}
	}
	
	public void makeWin() //Creating the arrays with the win 
	{
		win[0][0]=win[0][1]=win[0][2] = 0;
		win[1][0]=win[0][3]=win[0][4] = 1;
		win[2][0]=win[0][5]=win[0][6] = 2;
		win[1][1]=win[1][3]=win[0][7] = 3;
		win[1][2]=win[1][5]=win[1][7] = 4;
		win[1][4]=win[1][6]=win[2][7] = 5;
		win[2][3]=win[2][5]=win[0][8] = 6;
		win[2][1]=win[2][6]=win[1][8] = 7;
		win[2][2]=win[2][4]=win[2][8] = 8;
	}
	
	public void checkWin() //Using the owned value to check if 1 player owns all 3
	{
		for(int i=0; i<9; i++)
		{
			int c = 0;
			c = checkhelp(i);
			if ( c == 3)
			{
				gameOver=true;
				output.setText("The computer has won. Would you like to play again?");
			}
			if(c==-3)
			{
				gameOver=true;
				output.setText("You have won! Would you like to play again?");
			}
		}
	}
	
	public int checkhelp(int i) //Used to help add thing together
	{
		return field[win[0][i]].owned + field[win[1][i]].owned + field[win[2][i]].owned;
	}
	
	public void position (int xpos, int ypos, int loc) //Help make the circle
	{
		field[loc].x = xpos;
		field[loc].y = ypos;
	}
	
	public void ai() //Base stupid AI
	{
		int i=0;
		while (myTurn == false && gameOver == false)
		{
			field[i].newcolor();
			i++;
		}
	}
		
	public void actionPerformed(ActionEvent e) //From class
	{
		presses++;
		if(presses==1&&myTurn)
			output.setText("It is your turn.");
		else if(presses==1&&!myTurn)
		{
			ai();
			output.setText("It is your turn.");
		}
		else if(e.getSource()==color && !gameOver)
		{
			int x=Integer.parseInt(input.getText());
			if(0<=x && x<field.length)
				field[x].newcolor();
		}
		else if(e.getSource()==color&& gameOver)
			if(input.getText().charAt(0)=='Y'||input.getText().charAt(0)=='y')
			{
				for(int i=0; i<9; i++)
				{
					field[i].reset();
				}
				gameOver=false;
				output.setText("Please press the button to begin.");
				presses=0;
				if((int)(100*Math.random())%2==0)
					myTurn=true;
				else
				{
					myTurn=false;
				}
				
			}
			else if(input.getText().charAt(0)=='N'||input.getText().charAt(0)=='n')
			{
				System.out.println("Goodbye");
				System.exit(0);
			}
					

		repaint();
	}
	
	public gui7() //Mostly from class
	{
		addWindowListener( new close() );
		setSize(900,600);
		
		if((int)(100*Math.random())%2==0)
			myTurn=true;
		else
		{
			myTurn=false;
		}
		color=new JButton("Input");
		color.addActionListener(this);
		input=new JTextArea("5");
		playArea=new monalisa();
		output = new JLabel("Please press the button to begin.");
		
		field=new Circ[9];
		for(int i=0; i<field.length; i++)
			field[i]=new Circ();
		
		connect = new line[18];
		for (int i=0; i<connect.length; i++)
			connect[i]=new line(); 
		
		Container malcolm=getContentPane();
		malcolm.setLayout(new BorderLayout());
		
		malcolm.add( color,"East");
		malcolm.add( output,"North");
		malcolm.add( playArea,"Center");
		malcolm.add( input,"South");
		
		setTitle("gui7 - a braver newer water world!");
		setVisible(true);
	}
	
	public static void main(String [] args)
	{
		gui7 noOpinions=new gui7();
		
	}
}
